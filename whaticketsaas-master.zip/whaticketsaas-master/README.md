# WhaTicket Versão Saas com Módulo Kanban, Modo Noturno e as seguintes integrações:</br>

🗣️ DialogFlow</br>
🔄 N8N</br>
🌐 WebHooks</br>
🤖 TypeBot</br>
💬 ChatGPT</br>

Sugestão de VPS:

BASIC: 4 vCores, 6 GB de RAM e 100 GB de SSD NVMe $ 4.99 USD Mensal com taxa de setup de $ 4.99.

STANDARD: 4 vCores, 12 GB de RAM e 200 GB de SSD NVMe $ 7.99 USD Mensal com taxa de setup de $ 5.99.

```
https://control.peramix.com/?affid=14
```

24/07/2024 – Versão 5.0.0

🛠️ Fizemos correção no Vcard </br>
🔄 Função de habilitar e desabilitar novos registros</br>
⏳ Tempo de Trial disponível no Painel</br>
⚡ Respostas rápidas visualizadas por todos os usuários</br>
📞 Contatos agora aparece se é um número ok e o horário da última interação</br>
👀 Agora é possível ver o número que está conectado no Whaticket</br>
🔄 Botão para reiniciar conexões adicionado</br>
🎨 Alterar logo pelo Painel</br>
🆕 Adicionado nova ABA Cadastrar Empresa</br>
📋 Add Opção Plano Interno</br>

Caso queira fazer uma contribuição, serei muito grato.</br>
Chave Pix, aleatória:

```
efd3110c-e572-42b5-a6cb-5984a8811ad2
```
</br>

Biblioteca Baileys Atualizada:</br>

V 6.7.7

Instalador atualizado, versao NodeJS 20:

```
https://github.com/launcherbr/instalador.git
```
Notas Rápidas: </br>
Requer servidor Ubuntu 20.04 LTS com ao menos 4 vcore e 8gb de ram.</br>
Recomendamos Peramix, Contabo e Hetzner. </br>
Não recomendamos Hostinger, Hostgator e Locaweb.</br>

Siga o arquivo de Instruções para instalação:

```
https://drive.google.com/file/d/137rsR4o-vzNUDDg0M1eIal0wH29En3J4/view?usp=drivesdk
```

Confira no pdf aqui como gerar um webhook de retorno automático de pagamento da Efi.

```
https://drive.google.com/file/d/1Kjd-9NurK-7gw7_22-uIsZoB0MZ74YFp/view?usp=drivesdk
```
Personalizações:</br>
As instruções para alteração de cores, logo, icones e nome da instalação estão no arquivo de instruções.
